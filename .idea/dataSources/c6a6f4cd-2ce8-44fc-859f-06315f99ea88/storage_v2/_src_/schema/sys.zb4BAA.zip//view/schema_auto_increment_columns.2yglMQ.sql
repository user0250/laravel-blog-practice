create view schema_auto_increment_columns as
  select
    `COLUMNS`.`TABLE_SCHEMA`                                                                           AS `TABLE_SCHEMA`,
    `COLUMNS`.`TABLE_NAME`                                                                             AS `TABLE_NAME`,
    `COLUMNS`.`COLUMN_NAME`                                                                            AS `COLUMN_NAME`,
    `COLUMNS`.`DATA_TYPE`                                                                              AS `DATA_TYPE`,
    `COLUMNS`.`COLUMN_TYPE`                                                                            AS `COLUMN_TYPE`,
    (locate('unsigned', `COLUMNS`.`COLUMN_TYPE`) = 0)                                                  AS `is_signed`,
    (locate('unsigned', `COLUMNS`.`COLUMN_TYPE`) > 0)                                                  AS `is_unsigned`,
    ((case `COLUMNS`.`DATA_TYPE`
      when 'tinyint'
        then 255
      when 'smallint'
        then 65535
      when 'mediumint'
        then 16777215
      when 'int'
        then 4294967295
      when 'bigint'
        then 18446744073709551615 end) >> if((locate('unsigned', `COLUMNS`.`COLUMN_TYPE`) > 0), 0, 1)) AS `max_value`,
    `TABLES`.`AUTO_INCREMENT`                                                                          AS `AUTO_INCREMENT`,
    (`TABLES`.`AUTO_INCREMENT` / ((case `COLUMNS`.`DATA_TYPE`
                                   when 'tinyint'
                                     then 255
                                   when 'smallint'
                                     then 65535
                                   when 'mediumint'
                                     then 16777215
                                   when 'int'
                                     then 4294967295
                                   when 'bigint'
                                     then 18446744073709551615 end) >>
                                  if((locate('unsigned', `COLUMNS`.`COLUMN_TYPE`) > 0), 0,
                                     1)))                                                              AS `auto_increment_ratio`
  from (`information_schema`.`COLUMNS`
    join `information_schema`.`TABLES`
      on (((`COLUMNS`.`TABLE_SCHEMA` = `TABLES`.`TABLE_SCHEMA`) and (`COLUMNS`.`TABLE_NAME` = `TABLES`.`TABLE_NAME`))))
  where ((`COLUMNS`.`TABLE_SCHEMA` not in ('mysql', 'sys', 'INFORMATION_SCHEMA', 'performance_schema')) and
         (`TABLES`.`TABLE_TYPE` = 'BASE TABLE') and (`COLUMNS`.`EXTRA` = 'auto_increment'))
  order by (`TABLES`.`AUTO_INCREMENT` / ((case `COLUMNS`.`DATA_TYPE`
                                          when 'tinyint'
                                            then 255
                                          when 'smallint'
                                            then 65535
                                          when 'mediumint'
                                            then 16777215
                                          when 'int'
                                            then 4294967295
                                          when 'bigint'
                                            then 18446744073709551615 end) >>
                                         if((locate('unsigned', `COLUMNS`.`COLUMN_TYPE`) > 0), 0, 1))) desc,
    ((case `COLUMNS`.`DATA_TYPE`
      when 'tinyint'
        then 255
      when 'smallint'
        then 65535
      when 'mediumint'
        then 16777215
      when 'int'
        then 4294967295
      when 'bigint'
        then 18446744073709551615 end) >> if((locate('unsigned', `COLUMNS`.`COLUMN_TYPE`) > 0), 0, 1));

